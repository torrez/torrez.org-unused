[Turn wordwrap on]
XuMouse v2.5

Hello __________,
	Thank you for downloading my program. I was out looking for a mouse moving utility and only found versions that were crippleware and required payment for use. Charging for something so simple is ludicrous (nobody is going to get rich on a mouse moving utility), so I wrote my own version in an hour.

	You may download and redistribute this program however you like. I only ask that you keep this text file with it so people know where they can get the latest version.

	Yes, this utility is free in that you don't need to send me any money, however I would like it if you sent me a short email saying, "I'm using XuMouse! I'm so cool! Thank you!" or something to that effect. I never charge for any software I write, and so this is nice to receive from time to time.


FAQ:

What is a mouse moving utility?

There are companies who provide chances to win prizes as long as you watch their advertisements. These companies have written their programs to make sure you're watching by making sure there is activity on your computer (mice moving, keys being pressed). This program will move your mouse to random places on the screen at a set interval thus fooling the advertising programs into thinking you're still at your computer. Meantime you're out drinking kool-aid and eating twinkies.


What does Xu mean?

In Chinese "Xu" is pronounced "Hsu" which sounds a little like "Shoo"-- "Shoo" Mouse. Hehehe-hoho- I'm so funny.


This thing is great, how do I thank you?

Send an email to andre@torrez.org and I'll be happy.




		The latest version will always be at http://www.torrez.org/projects/xumouse.shtml




Andre Torrez
andre@torrez.org
October 2000